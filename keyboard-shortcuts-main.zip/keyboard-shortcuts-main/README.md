Shortcuts:
ctrl+shift+c = bsod computer
ctrl+alt+u = sleep
right arrow = alt tab
left arrow = switch window tab
ctrl+alt+i = shut down computer
up arrow = temporarely turn of shortcuts
ctrl+shift+up_arrow = re-enable shortcuts
down_arrow = stop running
ctrl+shift+y open app
