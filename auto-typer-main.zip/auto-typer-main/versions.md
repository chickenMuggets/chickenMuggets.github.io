v1

has no Gui have to go to the code to edit how many times it will repeat and what it will type

v2

added gui with tkinter

v3

improved gui design

v4

added fully customizable repeat amounts and improvered gui