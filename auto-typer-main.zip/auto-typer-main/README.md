# auto-typer
automatically types things 
